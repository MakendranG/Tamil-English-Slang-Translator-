# Setup & Deployment Guide

## Local Development Setup

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)
- Git

### Installation Steps

1. Clone the repository:
```bash
git clone [your-repository-url]
cd local-guide
```

2. Create a virtual environment (recommended):
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
python app.py
```

5. Open your browser and navigate to:
```
http://localhost:5000
```

## Testing the Application

### Manual Testing
1. Enter a slang term like "mass da"
2. Click "Translate" or press Enter
3. Verify translation appears with context
4. Try clicking example cards
5. Test "Show All Slang Terms" button

### Test Cases
- Valid slang: "mass da", "vera level", "sothapuna case"
- Partial matches: "mass" (should match "mass da")
- Invalid input: "xyz123" (should show error)
- Empty input: (should handle gracefully)

## Project Structure Explained

```
local guide/
├── .kiro/                      # Kiro AI configuration
│   └── steering/
│       └── product.md          # Custom Tamil slang context
├── app.py                      # Flask backend application
├── templates/
│   └── index.html             # Frontend HTML template
├── static/
│   └── style.css              # CSS styling
├── requirements.txt           # Python dependencies
├── .gitignore                 # Git ignore rules
├── README.md                  # Project documentation
├── BLOG_OUTLINE.md           # Blog post structure
└── SETUP_GUIDE.md            # This file
```

## Adding New Slang Terms

### Method 1: Update product.md
1. Open `.kiro/steering/product.md`
2. Add new slang entry following the format:
```markdown
**new slang** (தமிழ்)
- Meaning: English translation
- Context: When/how it's used
- Example: "Sample sentence" = "Translation"
```

### Method 2: Update app.py Dictionary
1. Open `app.py`
2. Add entry to `SLANG_DICTIONARY`:
```python
"new slang": {
    "translation": "English meaning",
    "context": "Usage context",
    "type": "urban"  # or "rural" or "common"
}
```

## Deployment Options

### Option 1: Heroku
```bash
# Install Heroku CLI
# Login to Heroku
heroku login

# Create new app
heroku create tamil-slang-translator

# Deploy
git push heroku main

# Open app
heroku open
```

### Option 2: PythonAnywhere
1. Sign up at pythonanywhere.com
2. Upload project files
3. Create new web app (Flask)
4. Configure WSGI file
5. Reload web app

### Option 3: AWS EC2
1. Launch EC2 instance (Ubuntu)
2. SSH into instance
3. Install Python and dependencies
4. Clone repository
5. Run with gunicorn:
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Option 4: Docker
Create `Dockerfile`:
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

Build and run:
```bash
docker build -t tamil-slang-translator .
docker run -p 5000:5000 tamil-slang-translator
```

## Environment Variables

For production, set these environment variables:
```bash
FLASK_ENV=production
FLASK_DEBUG=0
SECRET_KEY=your-secret-key-here
```

## Troubleshooting

### Port Already in Use
```bash
# Windows
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:5000 | xargs kill -9
```

### Module Not Found
```bash
pip install -r requirements.txt --upgrade
```

### Template Not Found
- Ensure `templates/` folder exists
- Check file name is exactly `index.html`
- Verify Flask app structure

### Static Files Not Loading
- Ensure `static/` folder exists
- Check CSS file name is exactly `style.css`
- Clear browser cache

## Performance Optimization

### For Production
1. Use gunicorn instead of Flask dev server:
```bash
pip install gunicorn
gunicorn -w 4 app:app
```

2. Enable caching for static files
3. Use CDN for assets
4. Implement rate limiting

## Security Considerations

1. Never commit sensitive data
2. Use environment variables for secrets
3. Implement CSRF protection
4. Add rate limiting for API endpoints
5. Sanitize user inputs
6. Use HTTPS in production

## Monitoring & Logging

Add logging to app.py:
```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@app.route('/translate', methods=['POST'])
def translate():
    logger.info(f"Translation request: {request.get_json()}")
    # ... rest of code
```

## Contributing

To contribute new slang terms:
1. Fork the repository
2. Add slang to product.md and app.py
3. Test locally
4. Submit pull request with examples

## Support

For issues or questions:
- GitHub Issues: [your-repo-url]/issues
- Email: [your-email]
- Documentation: See README.md

## License

[Specify your license here]

---

## Quick Reference Commands

```bash
# Start development server
python app.py

# Install dependencies
pip install -r requirements.txt

# Create virtual environment
python -m venv venv

# Activate virtual environment (Windows)
venv\Scripts\activate

# Activate virtual environment (Linux/Mac)
source venv/bin/activate

# Deactivate virtual environment
deactivate

# Freeze dependencies
pip freeze > requirements.txt

# Run with gunicorn (production)
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```
