from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

# Tamil slang dictionary based on product.md context
SLANG_DICTIONARY = {
    # Urban slang
    "mass da": {
        "translation": "That's awesome, cool, stylish",
        "context": "Used to appreciate something impressive",
        "type": "urban"
    },
    "mass": {
        "translation": "Awesome, cool, stylish",
        "context": "Appreciation term",
        "type": "urban"
    },
    "vera level": {
        "translation": "Next level, extraordinary, beyond expectations",
        "context": "Expressing something exceptional",
        "type": "urban"
    },
    "semma": {
        "translation": "Excellent, superb, amazing",
        "context": "Strong positive expression",
        "type": "urban"
    },
    "gethu": {
        "translation": "Swag, attitude, style",
        "context": "Describing someone's confident demeanor",
        "type": "urban"
    },
    "scene poduthu": {
        "translation": "Creating a scene, showing off",
        "context": "Can be positive or negative depending on tone",
        "type": "urban"
    },
    "build up": {
        "translation": "Hype, exaggeration, making something seem bigger",
        "context": "Often used for movie promotions or bragging",
        "type": "urban"
    },
    "thala": {
        "translation": "Boss, leader, chief",
        "context": "Term of respect or endearment",
        "type": "urban"
    },
    "machaan": {
        "translation": "Dude, bro, buddy",
        "context": "Casual term for male friends",
        "type": "urban"
    },
    "macha": {
        "translation": "Dude, bro, buddy",
        "context": "Casual term for male friends",
        "type": "urban"
    },
    "ponga": {
        "translation": "Get lost, go away",
        "context": "Playful or annoyed dismissal",
        "type": "urban"
    },
    "mokka": {
        "translation": "Boring, lame, disappointing",
        "context": "Expressing disappointment",
        "type": "urban"
    },
    
    # Village/Rural expressions
    "sothapuna case": {
        "translation": "A messed up situation, troublesome matter",
        "context": "Describing a problematic scenario",
        "type": "rural"
    },
    "ketta payyan": {
        "translation": "Naughty boy, mischievous person",
        "context": "Can be affectionate or critical",
        "type": "rural"
    },
    "enna koduma idhu": {
        "translation": "What cruelty is this, what injustice",
        "context": "Expressing shock or dismay",
        "type": "rural"
    },
    "adipoli": {
        "translation": "Fantastic, brilliant",
        "context": "Strong positive expression (borrowed from Malayalam)",
        "type": "rural"
    },
    "thimiru": {
        "translation": "Arrogance, ego",
        "context": "Usually negative",
        "type": "rural"
    },
    "loosu": {
        "translation": "Crazy, silly, foolish",
        "context": "Can be playful or insulting",
        "type": "rural"
    },
    "figure": {
        "translation": "Attractive person, good-looking",
        "context": "Describing physical appearance",
        "type": "rural"
    },
    "scene illa": {
        "translation": "No chance, not happening, no way",
        "context": "Rejecting a possibility",
        "type": "urban"
    },
    "adjust paniko": {
        "translation": "Manage with it, make do, compromise",
        "context": "Asking someone to be flexible",
        "type": "rural"
    },
    "timepass": {
        "translation": "Casual activity to kill time, not serious",
        "context": "Describing leisure activities",
        "type": "urban"
    },
    
    # Food & Daily Life
    "gana": {
        "translation": "Style of folk music, also means 'cool' in slang",
        "context": "Urban youth expression",
        "type": "urban"
    },
    "kuthu": {
        "translation": "Energetic dance/music style",
        "context": "Describing upbeat Tamil songs",
        "type": "urban"
    },
    "cutting chai": {
        "translation": "Half cup of tea",
        "context": "Tea shop ordering",
        "type": "urban"
    },
    
    # Emotional expressions
    "aiyayo": {
        "translation": "Oh no, expression of distress",
        "context": "Reacting to bad news",
        "type": "common"
    },
    "seri": {
        "translation": "Okay, alright, fine",
        "context": "Agreement or acceptance",
        "type": "common"
    },
    "po po": {
        "translation": "Go go, hurry up",
        "context": "Urging someone to leave quickly",
        "type": "common"
    }
}

def translate_slang(text):
    """Translate Tamil slang to English with context"""
    text_lower = text.lower().strip()
    
    # Check for exact matches first
    if text_lower in SLANG_DICTIONARY:
        slang_info = SLANG_DICTIONARY[text_lower]
        return {
            "found": True,
            "original": text,
            "translation": slang_info["translation"],
            "context": slang_info["context"],
            "type": slang_info["type"]
        }
    
    # Check for partial matches
    for slang, info in SLANG_DICTIONARY.items():
        if slang in text_lower:
            return {
                "found": True,
                "original": text,
                "slang_found": slang,
                "translation": info["translation"],
                "context": info["context"],
                "type": info["type"]
            }
    
    return {
        "found": False,
        "original": text,
        "message": "Slang not found in dictionary. Try phrases like 'mass da', 'vera level', or 'sothapuna case'"
    }

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/translate', methods=['POST'])
def translate():
    data = request.get_json()
    text = data.get('text', '')
    
    if not text:
        return jsonify({"error": "No text provided"}), 400
    
    result = translate_slang(text)
    return jsonify(result)

@app.route('/slang-list', methods=['GET'])
def slang_list():
    """Return all available slang terms"""
    slang_terms = []
    for term, info in SLANG_DICTIONARY.items():
        slang_terms.append({
            "term": term,
            "translation": info["translation"],
            "type": info["type"]
        })
    return jsonify(slang_terms)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
