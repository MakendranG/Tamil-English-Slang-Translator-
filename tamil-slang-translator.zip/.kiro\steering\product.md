# Tamil Slang Context Guide

This document teaches the AI about Tamil slang, cultural nuances, and local expressions used across Tamil Nadu.

## Urban Tamil Slang (Chennai & Cities)

### Common Expressions

**mass da / mass** (மாஸ் டா)
- Meaning: That's awesome, cool, stylish
- Context: Used to appreciate something impressive
- Example: "That bike is mass da!" = "That bike is really cool!"

**vera level** (வேற லெவல்)
- Meaning: Next level, extraordinary, beyond expectations
- Context: Expressing something exceptional
- Example: "His dance was vera level" = "His dance was extraordinary"

**semma** (செம்ம)
- Meaning: Excellent, superb, amazing
- Context: Strong positive expression
- Example: "Semma food!" = "Excellent food!"

**gethu** (கெத்து)
- Meaning: Swag, attitude, style
- Context: Describing someone's confident demeanor
- Example: "He has full gethu" = "He has great swag"

**scene poduthu** (சீன் போடுது)
- Meaning: Creating a scene, showing off
- Context: Can be positive or negative depending on tone
- Example: "He's scene poduthu" = "He's showing off"

**build up** (பில்ட் அப்)
- Meaning: Hype, exaggeration, making something seem bigger
- Context: Often used for movie promotions or bragging
- Example: "Too much build up for nothing" = "Too much hype for nothing"

**thala** (தல)
- Meaning: Boss, leader, chief (term of respect/endearment)
- Context: Used for friends or respected figures
- Example: "Thala is here!" = "The boss is here!"

**machaan / macha** (மச்சான்)
- Meaning: Dude, bro, buddy
- Context: Casual term for male friends
- Example: "What's up macha?" = "What's up dude?"

**ponga** (போங்க)
- Meaning: Get lost, go away (mild dismissal)
- Context: Playful or annoyed dismissal
- Example: "Ponga da!" = "Get out of here!"

**mokka** (மொக்க)
- Meaning: Boring, lame, disappointing
- Context: Expressing disappointment
- Example: "That movie was mokka" = "That movie was boring"

## Village/Rural Tamil Expressions

**sothapuna case** (சோதப்புன கேஸ்)
- Meaning: A messed up situation, troublesome matter
- Context: Describing a problematic scenario
- Example: "This is a sothapuna case" = "This is a messed up situation"

**ketta payyan** (கெட்ட பையன்)
- Meaning: Naughty boy, mischievous person
- Context: Can be affectionate or critical
- Example: "He's a ketta payyan" = "He's a naughty one"

**enna koduma idhu** (என்ன கொடுமை இது)
- Meaning: What cruelty is this, what injustice
- Context: Expressing shock or dismay
- Example: "Enna koduma idhu Saravanan!" = "What is this injustice!"

**adipoli** (அடிபொளி)
- Meaning: Fantastic, brilliant (borrowed from Malayalam)
- Context: Strong positive expression
- Example: "Adipoli performance!" = "Fantastic performance!"

**thimiru** (திமிரு)
- Meaning: Arrogance, ego
- Context: Usually negative
- Example: "Too much thimiru" = "Too much arrogance"

**loosu** (லூசு)
- Meaning: Crazy, silly, foolish
- Context: Can be playful or insulting
- Example: "Don't be loosu" = "Don't be silly"

**figure** (ஃபிகர்)
- Meaning: Attractive person, good-looking
- Context: Describing physical appearance
- Example: "She's a figure" = "She's attractive"

**scene illa** (சீன் இல்ல)
- Meaning: No chance, not happening, no way
- Context: Rejecting a possibility
- Example: "That plan? Scene illa" = "That plan? Not happening"

**adjust paniko** (அட்ஜஸ்ட் பண்ணிக்கோ)
- Meaning: Manage with it, make do, compromise
- Context: Asking someone to be flexible
- Example: "No space, adjust paniko" = "No space, manage with it"

**timepass** (டைம்பாஸ்)
- Meaning: Casual activity to kill time, not serious
- Context: Describing leisure activities
- Example: "Just timepass" = "Just killing time"

## Food & Daily Life Slang

**gana** (கான)
- Meaning: Style of folk music, also means "cool" in slang
- Context: Urban youth expression
- Example: "Gana song" = "Folk-style song"

**kuthu** (குத்து)
- Meaning: Energetic dance/music style
- Context: Describing upbeat Tamil songs
- Example: "Kuthu paatu" = "Energetic dance song"

**single piece / full meals**
- Meaning: Ordering style in local restaurants
- Context: Single piece = one item, full meals = complete thali
- Example: "One full meals" = "One complete meal platter"

**cutting chai** (கட்டிங் சாய்)
- Meaning: Half cup of tea
- Context: Tea shop ordering
- Example: "Two cutting chai" = "Two half cups of tea"

## Emotional Expressions

**aiyayo** (ஐயையோ)
- Meaning: Oh no, expression of distress
- Context: Reacting to bad news
- Example: "Aiyayo, what happened?" = "Oh no, what happened?"

**seri** (சரி)
- Meaning: Okay, alright, fine
- Context: Agreement or acceptance
- Example: "Seri, I'll come" = "Okay, I'll come"

**po po** (போ போ)
- Meaning: Go go, hurry up
- Context: Urging someone to leave quickly
- Example: "Po po, you'll be late" = "Go go, you'll be late"

## Usage Guidelines

When translating:
1. Provide the literal English meaning
2. Add cultural context when relevant
3. Explain the emotional tone (positive/negative/neutral)
4. Give usage examples
5. Note if it's urban vs rural usage
6. Mention if it's formal or casual

## Regional Variations

- Chennai: More English mixing, urban slang
- Madurai: Stronger dialect, more traditional expressions
- Coimbatore: Mix of Tamil and Kannada influences
- Villages: Pure Tamil, agricultural references

## Tone Indicators

- "da" / "di" - Casual suffix for friends (da = male, di = female)
- "nga" - Respectful suffix
- "pa" / "ma" - Affectionate suffix (pa = male, ma = female)
