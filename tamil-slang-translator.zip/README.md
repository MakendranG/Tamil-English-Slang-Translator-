# Tamil-English Slang Translator 🗣️

A local guide tool that translates Tamil slang (urban + village) into clear English explanations, powered by Kiro AI.

## Problem Statement

Tamil slang is rich, contextual, and constantly evolving. From Chennai's urban "mass da" to village expressions like "sothapuna case", these phrases carry cultural nuances that standard translators miss. This tool bridges that gap.

## Solution

A simple chat-based translator that:
- Understands Tamil slang from both urban and rural contexts
- Provides clear English explanations with cultural context
- Uses a custom `product.md` file to teach Kiro about local nuances

## Features

- Real-time slang translation
- Cultural context explanations
- Support for both urban and village Tamil expressions
- Simple web interface

## Tech Stack

- Python (Flask)
- HTML/CSS/JavaScript
- Kiro AI with custom context

## Project Structure

```
local guide/
├── .kiro/
│   └── steering/
│       └── product.md          # Custom context for Tamil slang
├── app.py                       # Flask backend
├── templates/
│   └── index.html              # Chat UI
├── static/
│   └── style.css               # Styling
├── requirements.txt            # Dependencies
└── README.md                   # This file
```

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
python app.py
```

3. Open browser at `http://localhost:5000`

## Example Translations

- "mass da" → "That's awesome/cool, bro!"
- "vera level" → "Next level, extraordinary"
- "sothapuna case" → "A messed up situation"

## How Kiro Accelerated Development

This project was built with Kiro AI assistance, which:
- Understood Tamil cultural context through custom product.md
- Generated the complete application structure
- Provided culturally-aware translations
- Accelerated development from concept to working prototype

## Submission

- **GitHub Repository**: [Your repo link]
- **AWS Builder Center Blog**: [Your blog link]
- **Theme**: The Local Guide
- **Challenge**: AI for Bharat

---

Built with ❤️ for Tamil culture
